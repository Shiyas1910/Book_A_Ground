package com.android.shiyas.bookaground.interfaces;

import com.android.shiyas.bookaground.models.Venue;

/**
 * Created by mohamed on 16-04-2019.
 */

public interface OnItemClickListener {
    void onItemClick(Venue item);
}
